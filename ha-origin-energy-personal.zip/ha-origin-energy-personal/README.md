# Origin Energy (Personal)

A private, read-only Home Assistant integration that imports **your own**
Origin Energy electricity usage and cost (hourly) into the Energy dashboard.

Approach and API findings are based on
[JKook-Plus/ha-origin-energy](https://github.com/JKook-Plus/ha-origin-energy)
(MIT). If you redistribute any of this, keep their copyright notice: copy the
`LICENSE` text from their repo into a `NOTICE` file here.

Unofficial; not affiliated with Origin Energy. It uses undocumented endpoints
and may break without warning. Treat the session cookie like a password.

## Auth values

`const.py` ships with the public Auth0 values (client id, audience, scope,
redirect URI) and browser headers documented by the original project, so
nothing needs filling in. If Origin ever rotates them, re-capture from
Firefox: sign in to originenergy.com.au with DevTools **closed**, then open
DevTools -> Network, reload, filter for `id.originenergy.com.au` and open an
`/authorize` request; they are its query parameters.

The auth flow (`auth.py`) follows the original project's: a silent
`/authorize?prompt=none&response_mode=web_message` call whose HTML response
contains the code, then a PKCE exchange at `/oauth/token`.

## Install

Copy `custom_components/origin_energy_personal` into your Home Assistant
`config/custom_components/` folder (or add the repo to HACS as a custom
repository, category Integration) and restart. Requires Home Assistant
2025.11 or newer.

The domain differs from the public integration, so both can be installed side
by side, but only run one against the same account.

## Set up

Settings -> Devices & services -> Add integration -> **Origin Energy
(Personal)**, then paste the `auth0` cookie:

1. Sign in at originenergy.com.au with DevTools closed.
2. In the same tab, open `https://id.originenergy.com.au/.well-known/jwks.json`.
3. F12 -> **Storage** -> Cookies -> `https://id.originenergy.com.au`.
4. Copy the full value of **`auth0`** (not `auth0_compat`) from the side pane.
   It starts with `s%3A`.

Each poll slides the cookie's expiry forward and saves the new value, so one
paste should last indefinitely. If it lapses, Home Assistant prompts you to
re-authenticate and your history is kept.

## Energy dashboard

Settings -> Dashboards -> Energy -> Grid consumption -> Add consumption:

- Energy imported from grid: `Origin Energy consumption`
- Cost tracking: **Use an entity tracking the total costs** -> `Origin Energy cost`
- Type of power measurement: **No power sensor**

The first run backfills in the background (about one request per week of
history, a few minutes), so reload and retry if the dropdowns are empty.
Check Developer tools -> Statistics for `origin_energy_personal:`.

## Notes

- Polls every 4 hours (Configure on the integration: 1-24). Origin data is a
  day behind, so this is not live.
- Re-reads 5 days back from the newest stored hour each poll, because Origin
  revises recent data.
- Only `ACTUAL`, `APPROXIMATE` and `PARTIAL` points are imported.
- Time zones with half-hour UTC offsets (e.g. Adelaide) are not handled;
  those points are skipped with a warning.
- Solar export (`totalFeedInEnergy`, `totalEarnings`) is queried but not yet
  written. See the TODO in `statistics.py` if you want to add it.
