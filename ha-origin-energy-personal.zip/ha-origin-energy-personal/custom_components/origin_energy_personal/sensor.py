"""Diagnostic timestamp sensors.

The energy data itself is NOT an entity: it lives in long-term statistics
(Developer tools -> Statistics) and is picked in the Energy dashboard.
"""
from __future__ import annotations

from datetime import datetime

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorEntityDescription,
)
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from . import OriginConfigEntry
from .const import CONF_AGREEMENT_ID, CONF_NMI, DOMAIN
from .coordinator import OriginCoordinator

DESCRIPTIONS = (
    SensorEntityDescription(
        key="last_update",
        translation_key="last_update",
        device_class=SensorDeviceClass.TIMESTAMP,
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
    SensorEntityDescription(
        key="last_reading",
        translation_key="last_reading",
        device_class=SensorDeviceClass.TIMESTAMP,
        entity_category=EntityCategory.DIAGNOSTIC,
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: OriginConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    async_add_entities(
        OriginSensor(entry.runtime_data, entry, d) for d in DESCRIPTIONS
    )


class OriginSensor(CoordinatorEntity[OriginCoordinator], SensorEntity):
    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator: OriginCoordinator,
        entry: OriginConfigEntry,
        description: SensorEntityDescription,
    ) -> None:
        super().__init__(coordinator)
        self.entity_description = description
        agreement = entry.data[CONF_AGREEMENT_ID]
        self._attr_unique_id = f"{agreement}_{description.key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, agreement)},
            name="Origin Energy",
            manufacturer="Origin Energy",
            model=entry.data.get(CONF_NMI) or None,
        )

    @property
    def native_value(self) -> datetime | None:
        if not self.coordinator.data:
            return None
        return self.coordinator.data.get(self.entity_description.key)
