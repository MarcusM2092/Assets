"""Polling coordinator: refresh token, fetch usage, import statistics."""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone, tzinfo
from typing import Any

import aiohttp

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed
from homeassistant.helpers.aiohttp_client import async_create_clientsession
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed
from homeassistant.util import dt as dt_util

from .api import (
    OriginEnergyApiClient,
    OriginEnergyApiError,
    parse_api_datetime,
    pick_service,
)
from .auth import (
    OriginAuthConfigError,
    OriginAuthError,
    OriginAuthTransientError,
    async_refresh_access_token,
)
from .const import (
    CONF_AGREEMENT_ID,
    CONF_COOKIE,
    CONF_SCAN_HOURS,
    DEFAULT_SCAN_HOURS,
    DOMAIN,
)
from .window import plan_chunks, plan_start
from .statistics import (
    HourlyUsage,
    async_get_last_start,
    async_write_statistics,
    feed_in_statistic_ids,
    parse_points,
    statistic_ids,
)

_LOGGER = logging.getLogger(__name__)


class OriginCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Owns the session, the auth cookie and the statistics import."""

    config_entry: ConfigEntry

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        self.interval_hours: int = entry.options.get(CONF_SCAN_HOURS, DEFAULT_SCAN_HOURS)
        super().__init__(
            hass,
            _LOGGER,
            config_entry=entry,
            name=DOMAIN,
            update_interval=timedelta(hours=self.interval_hours),
        )
        # Own session with a real cookie jar: the auth cookie is seeded into
        # it each poll and the rotated value is read back out (see auth.py).
        # Not the shared HA session, which must not carry Origin cookies.
        self._session = async_create_clientsession(
            hass, cookie_jar=aiohttp.CookieJar()
        )
        self._lock = asyncio.Lock()

    async def _async_update_data(self) -> dict[str, Any]:
        async with self._lock:
            token = await self._async_token()
            client = OriginEnergyApiClient(self._session, token)
            try:
                return await self._async_sync(client)
            except OriginEnergyApiError as err:
                raise UpdateFailed(str(err)) from err

    async def _async_token(self) -> str:
        cookie = self.config_entry.data[CONF_COOKIE]
        try:
            result = await async_refresh_access_token(self._session, cookie)
        except OriginAuthError as err:
            raise ConfigEntryAuthFailed(str(err)) from err
        except (OriginAuthTransientError, OriginAuthConfigError) as err:
            raise UpdateFailed(str(err)) from err

        if result.cookie != cookie:
            # Auth0 slid the session expiry; keep the new cookie so the
            # session stays alive indefinitely. (The options-change listener
            # ignores this, so it does not trigger a reload.)
            self.hass.config_entries.async_update_entry(
                self.config_entry,
                data={**self.config_entry.data, CONF_COOKIE: result.cookie},
            )
        return result.access_token

    async def _async_fetch(
        self,
        client: OriginEnergyApiClient,
        agreement_id: str,
        start: datetime,
        end: datetime,
        tz: tzinfo,
    ) -> tuple[dict[datetime, HourlyUsage], datetime | None, bool]:
        """Fetch [start, end] in chunks; returns hours, last reading, has_feed_in."""
        hours: dict[datetime, HourlyUsage] = {}  # de-dupes inclusive end dates
        last_reading: datetime | None = None
        has_feed_in = False
        for chunk_start, chunk_end in plan_chunks(start, end):
            window = await client.async_get_usage(agreement_id, chunk_start, chunk_end)
            has_feed_in = has_feed_in or window.has_feed_in
            for row in parse_points(
                window.points, window.consumption_unit, window.cost_unit, tz
            ):
                hours[row.start] = row
            if window.last_reading_date and (
                last_reading is None or window.last_reading_date > last_reading
            ):
                last_reading = window.last_reading_date
        return hours, last_reading, has_feed_in

    async def _async_sync(self, client: OriginEnergyApiClient) -> dict[str, Any]:
        agreement_id = self.config_entry.data[CONF_AGREEMENT_ID]

        services = await client.async_get_services()
        service = pick_service(services, agreement_id)
        if service is None or service.get("agreementId") != agreement_id:
            raise UpdateFailed(f"Agreement {agreement_id} not found on this account")

        tz_name = (
            (((service.get("property") or {}).get("address") or {}).get("components") or {})
            .get("timezone")
        )
        tz = (await dt_util.async_get_time_zone(tz_name)) if tz_name else None
        tz = tz or dt_util.get_default_time_zone()

        now = dt_util.utcnow()
        energy_id, _ = statistic_ids(agreement_id)
        last_start = await async_get_last_start(self.hass, energy_id)

        valid_from = parse_api_datetime(service.get("validFrom"), tz)
        if valid_from is not None:
            valid_from = valid_from.astimezone(timezone.utc)
        start = plan_start(now, last_start, valid_from)
        if last_start is None:
            _LOGGER.info("No statistics yet; backfilling from %s", start.date())

        hours, last_reading, has_feed_in = await self._async_fetch(
            client, agreement_id, start, now, tz
        )

        if has_feed_in:
            # Solar export stats are new to anyone who set this up before
            # feed-in support: if they don't exist yet, backfill them (and,
            # harmlessly and idempotently, the rest) from the agreement start.
            export_id, _ = feed_in_statistic_ids(agreement_id)
            if last_start is not None and await async_get_last_start(self.hass, export_id) is None:
                start = plan_start(now, None, valid_from)
                _LOGGER.info("Solar feed-in detected; backfilling export from %s", start.date())
                hours, last_reading, has_feed_in = await self._async_fetch(
                    client, agreement_id, start, now, tz
                )

        await async_write_statistics(
            self.hass, agreement_id, list(hours.values()), start, include_feed_in=has_feed_in
        )
        return {"last_update": dt_util.utcnow(), "last_reading": last_reading}
